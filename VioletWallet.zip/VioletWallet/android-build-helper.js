/*
 * Android Build Helper Script
 * 
 * This script assists in building an Android APK for the Card Wallet app
 * It works with Capacitor to simplify the Android build process
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

// Get current file's directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure we're in the project root
const projectRoot = process.cwd();

// Configuration
const appConfig = {
  appName: 'Card Wallet',
  appId: 'com.cardwallet.app',
  appVersion: '1.0.0',
  appBuildNumber: 1,
  webDir: 'dist',
  androidDir: path.join(projectRoot, 'android'),
  iconPath: path.join(projectRoot, 'generated-icon.png'),
};

// Main function to orchestrate the build process
async function buildAndroidApp() {
  try {
    console.log('\n📱 ANDROID APK BUILD ASSISTANT 📱\n');
    
    // Step 1: Build the web app
    console.log('⏳ Step 1: Building web application...');
    execSync('npm run build', { stdio: 'inherit' });
    console.log('✅ Web build completed\n');
    
    // Step 2: Create Capacitor config if it doesn't exist
    if (!fs.existsSync(path.join(projectRoot, 'capacitor.config.ts'))) {
      console.log('⏳ Step 2: Creating Capacitor configuration...');
      createCapacitorConfig();
      console.log('✅ Capacitor config created\n');
    } else {
      console.log('✅ Step 2: Capacitor config already exists\n');
    }
    
    // Step 3: Initialize Capacitor if needed
    console.log('⏳ Step 3: Initializing Capacitor...');
    try {
      execSync(`npx cap init "${appConfig.appName}" ${appConfig.appId} --web-dir=${appConfig.webDir}`, { stdio: 'inherit' });
      console.log('✅ Capacitor initialized\n');
    } catch (error) {
      console.log('ℹ️ Capacitor may already be initialized, continuing...\n');
    }
    
    // Step 4: Add Android platform if not already added
    if (!fs.existsSync(appConfig.androidDir)) {
      console.log('⏳ Step 4: Adding Android platform...');
      execSync('npx cap add android', { stdio: 'inherit' });
      console.log('✅ Android platform added\n');
    } else {
      console.log('✅ Step 4: Android platform already exists\n');
    }
    
    // Step 5: Update Android with latest web code
    console.log('⏳ Step 5: Copying web files to Android project...');
    execSync('npx cap copy android', { stdio: 'inherit' });
    console.log('✅ Web files copied to Android\n');
    
    // Step 6: Add NFC permissions to Android manifest
    console.log('⏳ Step 6: Adding NFC permissions to Android manifest...');
    addNfcPermissions();
    console.log('✅ NFC permissions added\n');
    
    // Step 7: Create custom NFC handler
    console.log('⏳ Step 7: Setting up NFC handler for Android...');
    createNfcHandler();
    console.log('✅ NFC handler created\n');
    
    // Step 8: Copy app icon
    console.log('⏳ Step 8: Setting up app icon...');
    if (fs.existsSync(appConfig.iconPath)) {
      console.log('ℹ️ Using custom icon from: ' + appConfig.iconPath);
      // Note: a real implementation would copy and resize the icon for various Android densities
      console.log('ℹ️ In a real build, this would be copied to Android res directories');
    } else {
      console.log('⚠️ Custom icon not found, Android will use default icon');
    }
    console.log('✅ Icon setup completed\n');
    
    // Step 9: Generate build instructions
    console.log('⏳ Step 9: Generating build instructions...');
    generateBuildInstructions();
    console.log('✅ Build instructions generated\n');
    
    console.log('🎉 Android setup complete! 🎉');
    console.log('To build the final APK, follow the instructions in BUILD-INSTRUCTIONS.md');
    
  } catch (error) {
    console.error('❌ Error during Android build process:');
    console.error(error);
    process.exit(1);
  }
}

// Helper function to create Capacitor config file
function createCapacitorConfig() {
  const configContent = `import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: '${appConfig.appId}',
  appName: '${appConfig.appName}',
  webDir: '${appConfig.webDir}',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1E1E2E",
      spinnerColor: "#6B2FD9",
      spinnerType: "crescent",
    },
  }
};

export default config;`;

  fs.writeFileSync(path.join(projectRoot, 'capacitor.config.ts'), configContent);
}

// Helper function to add NFC permissions to Android manifest
function addNfcPermissions() {
  const manifestPath = path.join(appConfig.androidDir, 'app/src/main/AndroidManifest.xml');
  
  if (fs.existsSync(manifestPath)) {
    let manifest = fs.readFileSync(manifestPath, 'utf-8');
    
    // Only add permissions if they don't already exist
    if (!manifest.includes('android.permission.NFC')) {
      manifest = manifest.replace(
        '</manifest>',
        `    <uses-permission android:name="android.permission.NFC" />
    <uses-feature android:name="android.hardware.nfc" android:required="true" />
    <uses-permission android:name="android.permission.VIBRATE" />
</manifest>`
      );
      
      fs.writeFileSync(manifestPath, manifest);
      console.log('  - Added NFC permissions to AndroidManifest.xml');
    } else {
      console.log('  - NFC permissions already exist in AndroidManifest.xml');
    }
  } else {
    console.log('⚠️ AndroidManifest.xml not found. Skipping NFC permission setup.');
  }
}

// Helper function to create a custom NFC handler
function createNfcHandler() {
  // Create directory for the custom handler
  const handlerDir = path.join(
    appConfig.androidDir, 
    'app/src/main/java/com/cardwallet/app'
  );
  
  if (!fs.existsSync(handlerDir)) {
    fs.mkdirSync(handlerDir, { recursive: true });
  }
  
  const handlerPath = path.join(handlerDir, 'NFCHandler.java');
  
  // Create the NFC handler implementation
  const handlerContent = `package com.cardwallet.app;

import android.app.Activity;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Toast;

import com.getcapacitor.BridgeActivity;

public class NFCHandler extends BridgeActivity {
    private NfcAdapter nfcAdapter;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Initialize NFC adapter
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        
        // Check if NFC is available on this device
        if (nfcAdapter == null) {
            Toast.makeText(this, "This device doesn't support NFC.", Toast.LENGTH_LONG).show();
        } else if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC to use tap to pay.", Toast.LENGTH_LONG).show();
        }
    }
    
    // This method is called when NFC is detected
    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        
        // Process NFC tag data
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction()) ||
            NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction()) ||
            NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            
            // Vibrate to indicate NFC was read
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
            }
            
            // Send event to JavaScript
            this.bridge.triggerWindowJSEvent("nfcTagDetected", "{}");
        }
    }
}`;

  fs.writeFileSync(handlerPath, handlerContent);
  console.log('  - Created NFCHandler.java');
}

// Helper function to generate build instructions
function generateBuildInstructions() {
  const instructionsPath = path.join(projectRoot, 'BUILD-INSTRUCTIONS.md');
  
  const instructionsContent = `# Building the Card Wallet Android APK

## Prerequisites

To build the Android APK, you'll need:

1. Android Studio (latest version)
2. JDK 11 or higher
3. Android SDK with build tools

## Steps to Build

1. **Open the Android Project**
   - Open Android Studio
   - Select "Open an Existing Project"
   - Navigate to: \`${appConfig.androidDir}\`
   - Click "Open"

2. **Wait for Gradle Sync**
   - Android Studio will automatically sync the project with Gradle
   - This may take a few minutes the first time

3. **Build the APK**
   - From the menu, select Build > Build Bundle(s) / APK(s) > Build APK(s)
   - Wait for the build to complete

4. **Locate the APK**
   - When the build is complete, a notification will appear
   - Click "locate" in the notification, or find the APK at:
     \`${appConfig.androidDir}/app/build/outputs/apk/debug/app-debug.apk\`

5. **Install on Device**
   - Enable "Install from Unknown Sources" in your device settings
   - Transfer the APK to your device
   - Open the APK file on your device to install

## Troubleshooting

If you encounter build issues:

1. Ensure all SDK components are installed via SDK Manager in Android Studio
2. Update Gradle version if prompted
3. Sync project with Gradle files if needed

## Features

The Android app includes:
- NFC support for tap-to-pay simulation
- Credit card management
- Custom UI with dark theme and purple accents

For further assistance, refer to the full project documentation.
`;

  fs.writeFileSync(instructionsPath, instructionsContent);
}

// Run the main function
buildAndroidApp();