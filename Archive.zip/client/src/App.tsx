import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import AddCard from "@/pages/AddCard";
import Settings from "@/pages/Settings";
import Pay from "@/pages/Pay";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/add-card" component={AddCard} />
      <Route path="/settings" component={Settings} />
      <Route path="/pay" component={Pay} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
