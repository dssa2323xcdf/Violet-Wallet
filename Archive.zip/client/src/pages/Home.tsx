import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import CardStack from '@/components/CardStack';
import Navigation from '@/components/Navigation';
import { Button } from '@/components/ui/button';
import { PlusCircle, Wallet } from 'lucide-react';
import FaceIdSimulation from '@/components/FaceIdSimulation';
import QuickPayNFC from '@/components/QuickPayNFC';
import { Card } from '@shared/schema';

export default function Home() {
  const [location, setLocation] = useLocation();
  const [showFaceId, setShowFaceId] = useState(false);
  const [showQuickPay, setShowQuickPay] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [lastTap, setLastTap] = useState(0);
  const [tapCount, setTapCount] = useState(0);
  
  // Get userId from localStorage
  const userId = parseInt(localStorage.getItem('userId') || '0');
  
  // Redirect to login if no userId
  useEffect(() => {
    if (!userId) {
      // For demo purposes, we'll use the demo user
      localStorage.setItem('userId', '1');
    }
  }, [userId]);
  
  // Fetch user data to check if Face ID is enabled
  const { data: user } = useQuery<{id: number, username: string, useFaceId: boolean}>({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });
  
  // Show Face ID screen on initial load if enabled
  useEffect(() => {
    if (user?.useFaceId && !isAuthenticated) {
      setShowFaceId(true);
    } else {
      setIsAuthenticated(true);
    }
  }, [user, isAuthenticated]);
  
  // Fetch cards
  const { 
    data: cards = [] as Card[], 
    isLoading,
    refetch 
  } = useQuery<Card[]>({
    queryKey: [`/api/users/${userId}/cards`],
    enabled: !!userId && isAuthenticated,
  });
  
  const handleFaceIdSuccess = () => {
    setShowFaceId(false);
    setIsAuthenticated(true);
  };
  
  const handleFaceIdCancel = () => {
    // For demo purposes, we'll authenticate anyway
    setShowFaceId(false);
    setIsAuthenticated(true);
  };
  
  // Handle the Apple Pay-like double tap
  const handleQuickPay = () => {
    const now = Date.now();
    const timeSinceLastTap = now - lastTap;
    
    // If the last tap was within 500ms, consider it a double tap
    if (timeSinceLastTap < 500 && timeSinceLastTap > 0) {
      setShowQuickPay(true);
      setTapCount(0);
    } else {
      // First tap
      setTapCount(prevCount => prevCount + 1);
      
      // Reset tap count after 1 second if no second tap
      setTimeout(() => {
        setTapCount(0);
      }, 1000);
    }
    
    setLastTap(now);
  };
  
  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {showFaceId && (
        <FaceIdSimulation
          onSuccess={handleFaceIdSuccess}
          onCancel={handleFaceIdCancel}
        />
      )}
      
      {showQuickPay && (
        <QuickPayNFC 
          userId={userId}
          onClose={() => setShowQuickPay(false)}
        />
      )}
      
      <header className="p-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-300 bg-clip-text text-transparent">
            Card Wallet
          </h1>
          <p className="text-slate-400 text-sm">Manage your cards securely</p>
        </div>
        
        <Button
          variant="ghost"
          size="icon"
          className="text-primary hover:text-primary hover:bg-primary/10"
          onClick={() => setLocation('/add-card')}
        >
          <PlusCircle className="h-6 w-6" />
        </Button>
      </header>
      
      <main className="p-6 max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-xl font-medium mb-6">Your Cards</h2>
          
          <CardStack
            cards={cards}
            onCardDeleted={refetch}
            isLoading={isLoading || !isAuthenticated}
          />
          
          {isAuthenticated && cards.length > 0 && (
            <div className="mt-6 flex flex-col items-center space-y-4">
              <p className="text-center text-sm text-slate-400">
                Tap on a card to see details
              </p>
              
              <Button
                variant="default"
                className="bg-primary hover:bg-primary/90"
                onClick={() => setLocation('/pay')}
              >
                <span className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 9L9 15M9 9l6 6" />
                  </svg>
                  Make Payment with NFC
                </span>
              </Button>
            </div>
          )}
          
          {isAuthenticated && cards.length === 0 && !isLoading && (
            <div className="mt-6 flex justify-center">
              <Button
                variant="outline"
                className="border-primary text-primary hover:bg-primary/10"
                onClick={() => setLocation('/add-card')}
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Your First Card
              </Button>
            </div>
          )}
        </motion.div>
      </main>
      
      <Navigation userId={userId} />
      
      {/* Floating Quick Pay Button (Apple Pay style) */}
      {isAuthenticated && cards.length > 0 && (
        <motion.div 
          className="fixed bottom-24 right-6 z-40"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5, type: "spring" }}
        >
          <motion.button
            className={`rounded-full w-16 h-16 flex items-center justify-center shadow-lg ${
              tapCount > 0 ? 'bg-primary/80' : 'bg-primary'
            }`}
            onClick={handleQuickPay}
            whileTap={{ scale: 0.95 }}
            animate={{
              boxShadow: tapCount > 0 
                ? "0 0 20px rgba(107, 47, 217, 0.8)" 
                : "0 4px 6px rgba(0, 0, 0, 0.1)"
            }}
            whileHover={{ 
              boxShadow: "0 0 15px rgba(107, 47, 217, 0.5)",
              scale: 1.05
            }}
          >
            <Wallet className="h-7 w-7 text-white" />
          </motion.button>
          <div className="text-center text-xs text-slate-400 mt-2">
            Double-tap to Pay
          </div>
        </motion.div>
      )}
    </div>
  );
}
