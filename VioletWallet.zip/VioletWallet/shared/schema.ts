import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  useFaceId: boolean("use_face_id").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  useFaceId: true,
});

// Card model
export const cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  cardholderName: text("cardholder_name").notNull(),
  lastFourDigits: text("last_four_digits").notNull(),
  encryptedCardNumber: text("encrypted_card_number").notNull(),
  encryptedCvv: text("encrypted_cvv").notNull(),
  expiryMonth: text("expiry_month").notNull(),
  expiryYear: text("expiry_year").notNull(),
  cardType: text("card_type").notNull(),
  color: text("color").notNull(),
  balance: text("balance").notNull().default("1250.75"),
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
});

// Extended version with validation for frontend forms
export const cardFormSchema = insertCardSchema.extend({
  cardNumber: z.string()
    .refine(
      (val) => /^\d{13,19}$/.test(val),
      { message: "Card number must be 13-19 digits" }
    )
    .refine(
      (val) => {
        // Luhn algorithm for credit card validation
        let sum = 0;
        let shouldDouble = false;
        // Loop through values starting from the rightmost digit
        for (let i = val.length - 1; i >= 0; i--) {
          let digit = parseInt(val.charAt(i));

          if (shouldDouble) {
            digit = digit * 2;
            if (digit > 9) {
              digit = digit - 9;
            }
          }

          sum += digit;
          shouldDouble = !shouldDouble;
        }
        return sum % 10 === 0;
      },
      { message: "Invalid card number" }
    ),
  cvv: z.string().refine(
    (val) => /^\d{3,4}$/.test(val),
    { message: "CVV must be 3 or 4 digits" }
  ),
  expiryMonth: z.string().refine(
    (val) => /^(0[1-9]|1[0-2])$/.test(val),
    { message: "Expiry month must be between 01-12" }
  ),
  expiryYear: z.string().refine(
    (val) => {
      const currentYear = new Date().getFullYear() % 100;
      const year = parseInt(val);
      return /^\d{2}$/.test(val) && year >= currentYear;
    },
    { message: "Expiry year must be valid and not in the past" }
  ),
});

// Type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCard = z.infer<typeof insertCardSchema>;
export type Card = typeof cards.$inferSelect;
export type CardFormData = z.infer<typeof cardFormSchema>;
