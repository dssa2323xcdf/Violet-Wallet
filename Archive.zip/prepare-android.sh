#!/bin/bash

echo "======================================"
echo "Card Wallet - Android Preparation Tool"
echo "======================================"
echo ""
echo "This script will prepare your web app for Android APK creation"
echo "It will set up the necessary files and configurations"
echo ""

# Make the script executable
chmod +x prepare-android.sh

# Run the Android Build Helper script
echo "Starting Android build preparation..."
node --experimental-modules android-build-helper.js

# Make Android gradle wrapper executable
if [ -d "android" ]; then
  echo ""
  echo "Making Android Gradle wrapper executable..."
  chmod +x android/gradlew
  echo "✅ Done"
fi

echo ""
echo "======================================"
echo "Android preparation complete!"
echo "For next steps, see BUILD-INSTRUCTIONS.md"
echo "======================================"