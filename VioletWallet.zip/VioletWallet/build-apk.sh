#!/bin/bash

echo "==== Building Android APK for Card Wallet ===="

# Make script executable
chmod +x build-apk.sh

# Step 1: Install Android SDK and tools
echo "Setting up Android build environment..."

# Create a directory for Android SDK
mkdir -p ~/android-sdk
export ANDROID_HOME=~/android-sdk
export PATH=$PATH:$ANDROID_HOME/tools/bin:$ANDROID_HOME/platform-tools

# Install Capacitor plugins for NFC functionality
echo "Installing Capacitor NFC plugin..."
npm install @capacitor-community/nfc

# Step 2: Build the web app
echo "Building web application..."
npm run build
if [ $? -ne 0 ]; then
    echo "Error: Web build failed"
    exit 1
fi
echo "✓ Web build completed successfully"

# Step 3: Update Capacitor config
cat > capacitor.config.ts << EOF
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cardwallet.app',
  appName: 'Card Wallet',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1E1E2E",
      spinnerColor: "#6B2FD9",
      spinnerType: "crescent",
    },
  }
};

export default config;
EOF

# Step 4: Initialize Capacitor project
echo "Initializing Capacitor project..."
npx cap init "Card Wallet" com.cardwallet.app --web-dir=dist

# Step 5: Add Android platform
echo "Adding Android platform..."
npx cap add android

# Step 6: Copy web files to Android project
echo "Copying web files to Android project..."
npx cap copy android

# Step 7: Add NFC permissions to Android manifest
echo "Adding NFC permissions to Android manifest..."
MANIFEST_FILE="android/app/src/main/AndroidManifest.xml"
if [ -f "$MANIFEST_FILE" ]; then
    # Insert permissions before the closing </manifest> tag
    sed -i '/<\/manifest>/i \
    <uses-permission android:name="android.permission.NFC" />\
    <uses-feature android:name="android.hardware.nfc" android:required="true" />\
    <uses-permission android:name="android.permission.VIBRATE" />' "$MANIFEST_FILE"
    echo "✓ NFC permissions added to Android manifest"
else
    echo "Warning: Could not find AndroidManifest.xml"
fi

# Step 8: Create a custom NFC handler in the Android project
echo "Creating NFC handler for Android..."
mkdir -p android/app/src/main/java/com/cardwallet/app/
cat > android/app/src/main/java/com/cardwallet/app/NFCHandler.java << EOF
package com.cardwallet.app;

import android.app.Activity;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Toast;

import com.getcapacitor.BridgeActivity;

public class NFCHandler extends BridgeActivity {
    private NfcAdapter nfcAdapter;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Initialize NFC adapter
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        
        // Check if NFC is available on this device
        if (nfcAdapter == null) {
            Toast.makeText(this, "This device doesn't support NFC.", Toast.LENGTH_LONG).show();
        } else if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC to use tap to pay.", Toast.LENGTH_LONG).show();
        }
    }
    
    // This method is called when NFC is detected
    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        
        // Process NFC tag data
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction()) ||
            NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction()) ||
            NfcAdapter.ACTION_TECH_DISCOVERED.equals(intent.getAction())) {
            
            // Vibrate to indicate NFC was read
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
            }
            
            // Send event to JavaScript
            this.bridge.triggerWindowJSEvent("nfcTagDetected", "{}");
        }
    }
}
EOF

# Step 9: Build the APK
echo "Building Android APK..."
cd android
if ./gradlew assembleDebug; then
    echo "✓ APK built successfully!"
    echo "Your APK is available at: android/app/build/outputs/apk/debug/app-debug.apk"
    
    # Copy the APK to a more accessible location
    mkdir -p ../build
    cp app/build/outputs/apk/debug/app-debug.apk ../build/CardWallet.apk
    echo "A copy is also available at: build/CardWallet.apk"
else
    echo "Error: APK build failed"
    echo "You may need to manually build the APK using Android Studio."
    echo "Instructions:"
    echo "1. Open the android folder in Android Studio"
    echo "2. Let Gradle sync complete"
    echo "3. Select Build > Build Bundle(s) / APK(s) > Build APK(s)"
    exit 1
fi

echo "==== Android APK Build Process Complete ===="
echo "To install on your Android device:"
echo "1. Enable 'Install from Unknown Sources' in your device settings"
echo "2. Transfer the APK file to your device"
echo "3. Open the APK file on your device to install"