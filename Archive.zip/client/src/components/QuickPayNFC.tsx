import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Wifi, CheckCircle, CreditCard, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

interface QuickPayNFCProps {
  userId: number;
  onClose: () => void;
}

export function QuickPayNFC({ userId, onClose }: QuickPayNFCProps) {
  const [status, setStatus] = useState<'initializing' | 'waiting' | 'scanning' | 'processing' | 'success' | 'failed'>('initializing');
  const [progress, setProgress] = useState(0);
  const [selectedCardIndex, setSelectedCardIndex] = useState(0);
  const { toast } = useToast();
  
  // Fetch cards
  const { 
    data: cards = [] as Card[], 
    isLoading,
  } = useQuery<Card[]>({
    queryKey: [`/api/users/${userId}/cards`],
    enabled: !!userId,
  });

  // Auto-select the first card if available
  useEffect(() => {
    if (cards.length > 0 && status === 'initializing') {
      setStatus('waiting');
    } else if (cards.length === 0 && status === 'initializing') {
      toast({
        title: "No Cards Available",
        description: "Please add a card before using quick pay",
        variant: "destructive",
      });
      onClose();
    }
  }, [cards, status, onClose, toast]);
  
  // Handle when user taps "Pay Now" button
  const handlePayNow = () => {
    setStatus('scanning');
    
    // Simulate NFC scanning
    const scanInterval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + (Math.random() * 15);
        if (newProgress >= 100) {
          clearInterval(scanInterval);
          setStatus('processing');
          
          // After "processing", show success
          setTimeout(() => {
            setStatus('success');
            
            // Close the dialog after showing success
            setTimeout(() => {
              onClose();
              
              // Show a success toast after closing
              toast({
                title: "Payment Successful",
                description: "Your purchase has been completed",
              });
            }, 2000);
          }, 1500);
          return 100;
        }
        return newProgress;
      });
    }, 200);
  };
  
  // Change to the next card
  const handleChangeCard = () => {
    if (cards.length > 1) {
      setSelectedCardIndex((prevIndex) => (prevIndex + 1) % cards.length);
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center"
    >
      <div className="absolute top-4 right-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="text-white"
        >
          <X className="h-6 w-6" />
        </Button>
      </div>
      
      <div className="flex flex-col items-center max-w-xs w-full mx-auto">
        {status === 'waiting' && cards.length > 0 && (
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full"
          >
            <div className="text-center mb-8">
              <div className="h-16 w-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center mb-2">
                <CreditCard className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-white">Quick Pay Ready</h2>
              <p className="text-slate-400 text-sm mt-1">Tap to pay with your default card</p>
            </div>
            
            <div 
              className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 mb-6 cursor-pointer"
              onClick={handleChangeCard}
            >
              <div className="flex items-center mb-2">
                <div 
                  className="w-10 h-7 rounded-md mr-3"
                  style={{
                    background: 
                      cards[selectedCardIndex].color === 'purple' ? 'linear-gradient(135deg, #8A2BE2 0%, #4B0082 100%)' :
                      cards[selectedCardIndex].color === 'blue' ? 'linear-gradient(135deg, #1E90FF 0%, #0000CD 100%)' :
                      cards[selectedCardIndex].color === 'black' ? 'linear-gradient(135deg, #2C3E50 0%, #000000 100%)' :
                      'linear-gradient(135deg, #FFD700 0%, #B8860B 100%)'
                  }}
                ></div>
                <div>
                  <p className="font-medium text-white">{cards[selectedCardIndex].cardType}</p>
                  <p className="text-sm text-slate-400">•••• {cards[selectedCardIndex].lastFourDigits}</p>
                </div>
                
                {cards.length > 1 && (
                  <div className="ml-auto text-xs text-primary">
                    Tap to change
                  </div>
                )}
              </div>
              
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{cards[selectedCardIndex].cardholderName}</span>
                <span className="text-slate-400">{cards[selectedCardIndex].expiryMonth}/{cards[selectedCardIndex].expiryYear}</span>
              </div>
            </div>
            
            <div className="text-center mb-4">
              <div className="flex items-center justify-center text-sm text-slate-400 mb-4">
                <ShieldCheck className="h-4 w-4 mr-1 text-green-500" />
                <span>Secure NFC payment</span>
              </div>
              
              <Button
                size="lg"
                className="w-full bg-primary hover:bg-primary/90"
                onClick={handlePayNow}
              >
                Pay Now
              </Button>
              <p className="text-xs text-slate-500 mt-2">
                Double tap to authorize payment at any terminal
              </p>
            </div>
          </motion.div>
        )}
        
        {status === 'scanning' && (
          <div className="text-center">
            <div className="relative mb-4">
              <svg className="w-32 h-32 mx-auto" viewBox="0 0 100 100">
                <circle 
                  cx="50" 
                  cy="50" 
                  r="40" 
                  fill="none" 
                  stroke="#333" 
                  strokeWidth="8"
                />
                <motion.circle 
                  cx="50" 
                  cy="50" 
                  r="40" 
                  fill="none" 
                  stroke="#6B2FD9" 
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray="250 250"
                  strokeDashoffset={250 - ((progress / 100) * 250)}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                >
                  <Wifi className="h-16 w-16 text-primary" />
                </motion.div>
              </div>
            </div>
            <h2 className="text-xl font-bold text-white">Hold Near Terminal</h2>
            <p className="text-slate-400 text-sm mt-1">Keep your device close to the payment terminal</p>
          </div>
        )}
        
        {status === 'processing' && (
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="w-32 h-32 mx-auto rounded-full border-4 border-primary flex items-center justify-center mb-4"
            >
              <motion.div
                animate={{ 
                  rotate: 360,
                  scale: [1, 1.1, 1]
                }}
                transition={{ 
                  rotate: { repeat: Infinity, duration: 2, ease: "linear" },
                  scale: { repeat: Infinity, duration: 1 }
                }}
              >
                <Wifi className="h-16 w-16 text-primary" />
              </motion.div>
            </motion.div>
            <h2 className="text-xl font-bold text-white">Processing Payment</h2>
            <p className="text-slate-400 text-sm mt-1">Please wait while we complete your transaction</p>
          </div>
        )}
        
        {status === 'success' && (
          <div className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10 }}
              className="mb-4"
            >
              <CheckCircle className="h-24 w-24 mx-auto text-green-500" />
            </motion.div>
            <h2 className="text-xl font-bold text-white">Payment Successful!</h2>
            <p className="text-slate-400 text-sm mt-1">Your transaction has been completed</p>
          </div>
        )}
        
        {status === 'failed' && (
          <div className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10 }}
              className="mb-4"
            >
              <X className="h-24 w-24 mx-auto p-4 bg-red-500/20 text-red-500 rounded-full" />
            </motion.div>
            <h2 className="text-xl font-bold text-white">Payment Failed</h2>
            <p className="text-slate-400 text-sm mt-1">There was a problem with your payment</p>
            <Button 
              variant="outline" 
              className="mt-4 border-slate-700"
              onClick={onClose}
            >
              Try Again
            </Button>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default QuickPayNFC;