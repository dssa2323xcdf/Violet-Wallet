// Android APK Builder
// This script builds the Android APK step by step

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import readline from 'readline';
import { fileURLToPath } from 'url';

// Get current file's directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log(`
╔═══════════════════════════════════════════╗
║        CARD WALLET - ANDROID BUILD        ║
╚═══════════════════════════════════════════╝

This script will build an Android APK from your web app.
`);

// Ask for confirmation before proceeding
rl.question('Do you want to proceed with building the Android APK? (y/n) ', (answer) => {
  if (answer.toLowerCase() !== 'y') {
    console.log('Build process cancelled.');
    rl.close();
    return;
  }
  
  buildAndroidApk();
  rl.close();
});

function buildAndroidApk() {
  try {
    console.log('\nStarting APK build process...');
    
    // Step 1: Build the web application
    console.log('\n[Step 1/5] Building web application...');
    execSync('npm run build', { stdio: 'inherit' });
    console.log('✓ Web build completed');
    
    // Step 2: Create index.html in the dist directory
    console.log('\n[Step 2/5] Setting up web assets for Capacitor...');
    if (!fs.existsSync('dist/index.html')) {
      console.log('  Creating index.html in dist folder...');
      const publicIndexPath = 'dist/public/index.html';
      
      if (fs.existsSync(publicIndexPath)) {
        const indexContent = fs.readFileSync(publicIndexPath, 'utf-8');
        fs.writeFileSync('dist/index.html', indexContent);
        console.log('  ✓ index.html created in dist folder');
      } else {
        console.log('  ✗ Could not find public/index.html');
        throw new Error('Missing index.html in dist/public. Build process failed.');
      }
    }
    
    // Step 3: Initialize Capacitor
    console.log('\n[Step 3/5] Initializing Capacitor...');
    // Create a capacitor.config.ts file
    const capacitorConfig = `import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cardwallet.app',
  appName: 'Card Wallet',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1E1E2E",
      spinnerColor: "#6B2FD9",
      spinnerType: "crescent",
    },
  }
};

export default config;
`;
    fs.writeFileSync('capacitor.config.ts', capacitorConfig);
    console.log('  ✓ Capacitor config created');
    
    try {
      execSync('npx cap init "Card Wallet" com.cardwallet.app --web-dir=dist', { stdio: 'inherit' });
      console.log('  ✓ Capacitor initialized');
    } catch (error) {
      console.log('  ▲ Capacitor initialization error - continuing anyway');
    }
    
    // Step 4: Add Android platform
    console.log('\n[Step 4/5] Adding Android platform...');
    execSync('npx cap add android', { stdio: 'inherit' });
    console.log('  ✓ Android platform added');
    
    // Step 5: Add NFC permissions and capabilities
    console.log('\n[Step 5/5] Adding NFC capabilities...');
    const manifestPath = 'android/app/src/main/AndroidManifest.xml';
    
    if (fs.existsSync(manifestPath)) {
      let manifest = fs.readFileSync(manifestPath, 'utf-8');
      
      // Only add permissions if they don't already exist
      if (!manifest.includes('android.permission.NFC')) {
        manifest = manifest.replace(
          '</manifest>',
          `    <uses-permission android:name="android.permission.NFC" />
    <uses-feature android:name="android.hardware.nfc" android:required="true" />
    <uses-permission android:name="android.permission.VIBRATE" />
</manifest>`
        );
        
        fs.writeFileSync(manifestPath, manifest);
        console.log('  ✓ NFC permissions added to AndroidManifest.xml');
      }
    }
    
    // Make gradlew executable
    try {
      fs.chmodSync('android/gradlew', '755');
      console.log('  ✓ Made gradlew executable');
    } catch (error) {
      console.log('  ▲ Could not make gradlew executable');
    }
    
    // Generate build instructions
    const instructions = `# Building Card Wallet APK

## Prerequisites
- Android Studio
- JDK 11+
- Android SDK

## Build Steps

1. Open the android folder in Android Studio:
   \`\`\`
   android/
   \`\`\`

2. Let Android Studio sync the project

3. Build the APK:
   Build > Build Bundle(s) / APK(s) > Build APK(s)

4. The APK will be available at:
   \`\`\`
   android/app/build/outputs/apk/debug/app-debug.apk
   \`\`\`

## Features
- NFC payment simulation
- 3D card management
- Dark theme with purple LED accents
`;
    
    fs.writeFileSync('ANDROID-BUILD.md', instructions);
    
    console.log(`
╔═══════════════════════════════════════════╗
║        ANDROID SETUP COMPLETED!           ║
╚═══════════════════════════════════════════╝

Your Android project has been set up in the 'android' folder.

To build the final APK, you'll need Android Studio. See instructions 
in the ANDROID-BUILD.md file.

The APK can be installed on Android devices to experience
your Card Wallet app as a native application with NFC
payment capabilities.
`);
    
  } catch (error) {
    console.error('\n❌ Error during build process:');
    console.error(error);
    process.exit(1);
  }
}