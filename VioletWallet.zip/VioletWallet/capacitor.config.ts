import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cardwallet.app',
  appName: 'Card Wallet',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1E1E2E",
      spinnerColor: "#6B2FD9",
      spinnerType: "crescent",
    },
  }
};

export default config;
