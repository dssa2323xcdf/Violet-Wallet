#!/usr/bin/env node

/*
 * Card Wallet - Android Setup Script
 * 
 * This script prepares the web app for Android APK creation by:
 * 1. Building the web application
 * 2. Setting up Capacitor configuration
 * 3. Creating the Android project
 * 4. Adding NFC support
 * 5. Generating build instructions
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

// Get current file's directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = process.cwd();

// App configuration
const APP_CONFIG = {
  name: 'Card Wallet',
  id: 'com.cardwallet.app',
  version: '1.0.0',
  webDir: 'dist/public',
  androidDir: path.join(projectRoot, 'android')
};

// ASCII art banner
const showBanner = () => {
  console.log(`
═══════════════════════════════════════════
    CARD WALLET - ANDROID SETUP WIZARD     
═══════════════════════════════════════════
  Convert your web app to a native Android  
  application with NFC payment support      
═══════════════════════════════════════════
`);
};

// Run a command and return whether it succeeded
const runCommand = (command, errorMessage) => {
  try {
    execSync(command, { stdio: 'inherit' });
    return true;
  } catch (error) {
    console.error(`❌ ${errorMessage}`);
    console.error(`   ${error.message}`);
    return false;
  }
};

// Step 1: Build the web application
const buildWebApp = () => {
  console.log('📱 Step 1: Building the web application');
  
  if (!runCommand('npm run build', 'Failed to build web application')) {
    console.log('   Attempting to fix common build issues...');
    if (!runCommand('npm run build', 'Failed to build web application after retry')) {
      return false;
    }
  }
  
  console.log('✅ Web build completed successfully\n');
  return true;
};

// Step 2: Create or update Capacitor configuration
const setupCapacitorConfig = () => {
  console.log('📱 Step 2: Setting up Capacitor configuration');
  
  const configPath = path.join(projectRoot, 'capacitor.config.ts');
  const configContent = `import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: '${APP_CONFIG.id}',
  appName: '${APP_CONFIG.name}',
  webDir: '${APP_CONFIG.webDir}',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1E1E2E",
      spinnerColor: "#6B2FD9",
      spinnerType: "crescent",
    },
  }
};

export default config;`;

  try {
    fs.writeFileSync(configPath, configContent);
    console.log('✅ Capacitor configuration created/updated\n');
    return true;
  } catch (error) {
    console.error(`❌ Failed to create Capacitor configuration: ${error.message}`);
    return false;
  }
};

// Step 3: Initialize Capacitor project
const initializeCapacitor = () => {
  console.log('📱 Step 3: Initializing Capacitor project');
  
  try {
    execSync(`npx cap init "${APP_CONFIG.name}" ${APP_CONFIG.id} --web-dir=${APP_CONFIG.webDir}`, 
      { stdio: 'inherit' });
    console.log('✅ Capacitor initialized successfully\n');
    return true;
  } catch (error) {
    // Initialization might fail if already initialized, which is not a critical error
    console.log('ℹ️ Capacitor may already be initialized, continuing\n');
    return true;
  }
};

// Step 4: Add Android platform
const addAndroidPlatform = () => {
  console.log('📱 Step 4: Adding Android platform');
  
  // Skip if Android platform already exists
  if (fs.existsSync(APP_CONFIG.androidDir)) {
    console.log('ℹ️ Android platform already exists, skipping\n');
    return true;
  }
  
  if (!runCommand('npx cap add android', 'Failed to add Android platform')) {
    return false;
  }
  
  console.log('✅ Android platform added successfully\n');
  return true;
};

// Step 5: Copy web files to Android project
const copyWebToAndroid = () => {
  console.log('📱 Step 5: Copying web files to Android project');
  
  if (!runCommand('npx cap copy android', 'Failed to copy web files to Android')) {
    return false;
  }
  
  console.log('✅ Web files copied to Android successfully\n');
  return true;
};

// Step 6: Add NFC permissions to Android manifest
const addNfcPermissions = () => {
  console.log('📱 Step 6: Adding NFC permissions');
  
  const manifestPath = path.join(APP_CONFIG.androidDir, 'app/src/main/AndroidManifest.xml');
  
  if (!fs.existsSync(manifestPath)) {
    console.error('❌ AndroidManifest.xml not found');
    return false;
  }
  
  try {
    let manifest = fs.readFileSync(manifestPath, 'utf-8');
    
    // Only add permissions if they don't already exist
    if (!manifest.includes('android.permission.NFC')) {
      manifest = manifest.replace(
        '</manifest>',
        `    <uses-permission android:name="android.permission.NFC" />
    <uses-feature android:name="android.hardware.nfc" android:required="true" />
    <uses-permission android:name="android.permission.VIBRATE" />
</manifest>`
      );
      
      fs.writeFileSync(manifestPath, manifest);
      console.log('✅ NFC permissions added to Android manifest\n');
    } else {
      console.log('ℹ️ NFC permissions already exist in AndroidManifest.xml\n');
    }
    
    return true;
  } catch (error) {
    console.error(`❌ Failed to update Android manifest: ${error.message}`);
    return false;
  }
};

// Step 7: Generate build instructions
const generateBuildInstructions = () => {
  console.log('📱 Step 7: Generating build instructions');
  
  const instructionsPath = path.join(projectRoot, 'BUILD-INSTRUCTIONS.md');
  
  const instructionsContent = `# Building the Card Wallet Android APK

## Prerequisites

To build the Android APK, you'll need:

1. Android Studio (latest version)
2. JDK 11 or higher
3. Android SDK with build tools

## Steps to Build

1. **Open the Android Project**
   - Open Android Studio
   - Select "Open an Existing Project"
   - Navigate to: \`${APP_CONFIG.androidDir}\`
   - Click "Open"

2. **Wait for Gradle Sync**
   - Android Studio will automatically sync the project with Gradle
   - This may take a few minutes the first time

3. **Build the APK**
   - From the menu, select Build > Build Bundle(s) / APK(s) > Build APK(s)
   - Wait for the build to complete

4. **Locate the APK**
   - When the build is complete, a notification will appear
   - Click "locate" in the notification, or find the APK at:
     \`${APP_CONFIG.androidDir}/app/build/outputs/apk/debug/app-debug.apk\`

5. **Install on Device**
   - Enable "Install from Unknown Sources" in your device settings
   - Transfer the APK to your device
   - Open the APK file on your device to install

## Features

The Android app includes:
- NFC support for tap-to-pay simulation  
- Credit card management with 3D visualization
- Dark theme with purple LED accents

## Test NFC Payment

1. Add a card in the app
2. Tap the Quick Pay button next to a card
3. Place your device near an NFC tag or another NFC-enabled device
4. The app will simulate a payment transaction

For technical details on the NFC implementation, see the NFCHandler.java file.`;

  try {
    fs.writeFileSync(instructionsPath, instructionsContent);
    console.log('✅ Build instructions generated\n');
    return true;
  } catch (error) {
    console.error(`❌ Failed to create build instructions: ${error.message}`);
    return false;
  }
};

// Main function to run all steps
const main = async () => {
  showBanner();
  
  console.log('Starting Android setup process...\n');
  
  // Run all the steps in sequence
  const steps = [
    buildWebApp,
    setupCapacitorConfig,
    initializeCapacitor,
    addAndroidPlatform,
    copyWebToAndroid,
    addNfcPermissions,
    generateBuildInstructions
  ];
  
  for (const step of steps) {
    if (!await step()) {
      console.error('\n❌ Android setup failed');
      return;
    }
  }
  
  // Make gradlew executable if it exists
  const gradlewPath = path.join(APP_CONFIG.androidDir, 'gradlew');
  if (fs.existsSync(gradlewPath)) {
    try {
      fs.chmodSync(gradlewPath, '755');
      console.log('✅ Made gradlew executable\n');
    } catch (error) {
      console.log(`⚠️ Couldn't make gradlew executable: ${error.message}\n`);
    }
  }
  
  console.log(`
═══════════════════════════════════════════
     🎉  ANDROID SETUP COMPLETE!  🎉      
═══════════════════════════════════════════
 
 Your Card Wallet app is ready for Android!
 
 To build the APK, follow the instructions in:
   BUILD-INSTRUCTIONS.md
 
 This will allow you to install the app on
 any Android device.
═══════════════════════════════════════════
`);
};

// Run the main function
main().catch(error => {
  console.error('Unhandled error:', error);
  process.exit(1);
});