#!/bin/bash

echo "==============================================="
echo "      Card Wallet - Android APK Builder       "
echo "==============================================="

# Make script executable
chmod +x make-apk.sh

# Run the APK builder script
echo "Starting APK build process..."
echo "y" | node --experimental-modules android-apk-builder.js

# If Android directory exists, instructions for further steps
if [ -d "android" ]; then
  echo ""
  echo "==============================================="
  echo "The Android project was successfully created!"
  echo "See ANDROID-BUILD.md for instructions on how"
  echo "to build the final APK using Android Studio."
  echo "==============================================="
fi