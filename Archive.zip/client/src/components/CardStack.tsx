import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card as CardType } from '@shared/schema';
import Card3D from './Card3D';
import { Button } from '@/components/ui/button';
import { AlertCircle, Trash2 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import QuickPayNFC from './QuickPayNFC';

interface CardStackProps {
  cards: CardType[];
  onCardDeleted: () => void;
  isLoading?: boolean;
}

export function CardStack({ cards, onCardDeleted, isLoading = false }: CardStackProps) {
  const [selectedCardIndex, setSelectedCardIndex] = useState<number | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showQuickPay, setShowQuickPay] = useState(false);
  const [quickPayCard, setQuickPayCard] = useState<CardType | null>(null);
  const { toast } = useToast();

  // Reset selection when cards change
  useEffect(() => {
    if (cards.length === 0) {
      setSelectedCardIndex(null);
    } else if (selectedCardIndex !== null && selectedCardIndex >= cards.length) {
      setSelectedCardIndex(cards.length - 1);
    }
  }, [cards, selectedCardIndex]);

  const handleCardClick = (index: number) => {
    setSelectedCardIndex(selectedCardIndex === index ? null : index);
  };

  const deleteCard = async (cardId: number) => {
    try {
      setIsDeleting(true);
      await apiRequest('DELETE', `/api/cards/${cardId}`);
      toast({
        title: "Card Deleted",
        description: "Your card has been deleted successfully.",
      });
      onCardDeleted();
    } catch (error) {
      console.error('Error deleting card:', error);
      toast({
        title: "Error",
        description: "Failed to delete the card. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-80 w-full">
        <div className="animate-pulse flex space-x-4">
          <div className="rounded-xl bg-slate-700 h-40 w-64"></div>
        </div>
        <p className="mt-4 text-muted-foreground">Loading your cards...</p>
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-80 w-full border-2 border-dashed border-slate-700 rounded-xl p-6">
        <AlertCircle className="h-10 w-10 text-primary mb-4" />
        <h3 className="text-xl font-medium mb-2">No cards yet</h3>
        <p className="text-muted-foreground text-center mb-4">
          You haven't added any cards to your wallet yet.
        </p>
      </div>
    );
  }

  return (
    <div className="relative w-full">
      {/* Quick Pay Modal */}
      {showQuickPay && quickPayCard && (
        <QuickPayNFC 
          userId={quickPayCard.userId}
          onClose={() => setShowQuickPay(false)}
        />
      )}
      
      {/* Card stack */}
      <div className="relative h-80 w-full flex items-center justify-center">
        <AnimatePresence>
          {cards.map((card, index) => {
            // Calculate position in stack
            const isSelected = selectedCardIndex === index;
            const zIndex = cards.length - index;
            const offset = index * 4; // Overlap offset
            
            return (
              <Card3D
                key={card.id}
                card={card}
                isSelected={isSelected}
                onClick={() => handleCardClick(index)}
                onQuickPay={() => {
                  setQuickPayCard(card);
                  setShowQuickPay(true);
                }}
                style={{
                  position: 'absolute',
                  zIndex,
                  transform: `translateY(${isSelected ? 0 : offset}px)`,
                }}
              />
            );
          })}
        </AnimatePresence>
      </div>

      {/* Card details section */}
      <AnimatePresence>
        {selectedCardIndex !== null && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="mt-4 p-4 bg-slate-900/60 backdrop-blur-sm rounded-lg"
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-lg font-medium">Card Details</h3>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => deleteCard(cards[selectedCardIndex].id)}
                disabled={isDeleting}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                {isDeleting ? "Deleting..." : "Delete Card"}
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Cardholder Name</p>
                <p className="font-medium">{cards[selectedCardIndex].cardholderName}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Card Number</p>
                <p className="font-medium">•••• •••• •••• {cards[selectedCardIndex].lastFourDigits}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Expiry Date</p>
                <p className="font-medium">
                  {cards[selectedCardIndex].expiryMonth}/{cards[selectedCardIndex].expiryYear}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Card Type</p>
                <p className="font-medium">{cards[selectedCardIndex].cardType}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default CardStack;
