import { Home, CreditCard, Settings, DollarSign } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';

interface NavigationProps {
  userId: number;
}

export function Navigation({ userId }: NavigationProps) {
  const [location] = useLocation();

  // Define navigation items (removed Add Card and Pay buttons as requested)
  const navItems = [
    {
      icon: Home,
      label: 'Home',
      href: '/',
    },
    {
      icon: Settings,
      label: 'Settings',
      href: '/settings',
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/80 backdrop-blur-lg border-t border-slate-800 p-2 z-50">
      <div className="max-w-md mx-auto flex justify-around">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <a className="relative flex flex-col items-center px-4 py-2 text-xs">
                <div className="relative">
                  {isActive && (
                    <motion.div
                      layoutId="navHighlight"
                      className="absolute -inset-2 rounded-full bg-primary/20"
                      initial={false}
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                  <item.icon className={`h-6 w-6 mb-1 ${isActive ? 'text-primary' : 'text-slate-400'}`} />
                </div>
                <span className={isActive ? 'text-primary' : 'text-slate-400'}>
                  {item.label}
                </span>
              </a>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export default Navigation;
