#!/bin/bash

echo "==== Starting Android APK Build Process ===="

# Make script executable
chmod +x build-android.sh

# Step 1: Build the web app
echo "Building web application..."
npm run build
if [ $? -ne 0 ]; then
    echo "Error: Web build failed"
    exit 1
fi
echo "✓ Web build completed successfully"

# Step 2: Initialize Capacitor (only needed first time)
echo "Initializing Capacitor project..."
npx cap init "Card Wallet" com.cardwallet.app --web-dir=dist
if [ $? -ne 0 ]; then
    echo "Error: Capacitor initialization failed"
    exit 1
fi
echo "✓ Capacitor initialized successfully"

# Step 3: Add Android platform
echo "Adding Android platform..."
npx cap add android
if [ $? -ne 0 ]; then
    echo "Error: Failed to add Android platform"
    exit 1
fi
echo "✓ Android platform added successfully"

# Step 4: Copy built web files to Android project
echo "Copying web files to Android project..."
npx cap copy android
if [ $? -ne 0 ]; then
    echo "Error: Failed to copy web files to Android"
    exit 1
fi
echo "✓ Web files copied to Android successfully"

# Step 5: Add NFC permissions to Android manifest
echo "Adding NFC permissions to Android manifest..."
MANIFEST_FILE="android/app/src/main/AndroidManifest.xml"
if [ -f "$MANIFEST_FILE" ]; then
    # Insert permissions before the closing </manifest> tag
    sed -i '/<\/manifest>/i \
    <uses-permission android:name="android.permission.NFC" />\
    <uses-feature android:name="android.hardware.nfc" android:required="true" />\
    <uses-permission android:name="android.permission.VIBRATE" />' "$MANIFEST_FILE"
    echo "✓ NFC permissions added to Android manifest"
else
    echo "Warning: Could not find AndroidManifest.xml"
fi

# Step 6: Customize Android app icon (if needed)
echo "Note: To customize Android app icon, place your icon files in android/app/src/main/res/ directories"

# Step 7: Build the APK
echo "Building Android APK..."
cd android
if ./gradlew assembleDebug; then
    echo "✓ APK built successfully!"
    echo "Your APK is available at: android/app/build/outputs/apk/debug/app-debug.apk"
    
    # Copy the APK to a more accessible location
    mkdir -p ../build
    cp app/build/outputs/apk/debug/app-debug.apk ../build/CardWallet.apk
    echo "A copy is also available at: build/CardWallet.apk"
else
    echo "Error: APK build failed"
    exit 1
fi

echo "==== Android APK Build Process Complete ===="
echo "To install on an Android device, transfer the APK file and install it directly."