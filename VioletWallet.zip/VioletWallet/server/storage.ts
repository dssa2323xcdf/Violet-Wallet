import { 
  users, 
  cards, 
  type User, 
  type InsertUser, 
  type Card, 
  type InsertCard 
} from "@shared/schema";

// Storage interface with CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserFaceIdSetting(userId: number, useFaceId: boolean): Promise<User | undefined>;
  
  // Card methods
  getCards(userId: number): Promise<Card[]>;
  getCard(id: number): Promise<Card | undefined>;
  createCard(card: InsertCard): Promise<Card>;
  deleteCard(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private cards: Map<number, Card>;
  private userIdCounter: number;
  private cardIdCounter: number;

  constructor() {
    this.users = new Map();
    this.cards = new Map();
    this.userIdCounter = 1;
    this.cardIdCounter = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      useFaceId: insertUser.useFaceId ?? false
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserFaceIdSetting(userId: number, useFaceId: boolean): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, useFaceId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Card methods
  async getCards(userId: number): Promise<Card[]> {
    return Array.from(this.cards.values()).filter(
      (card) => card.userId === userId
    );
  }

  async getCard(id: number): Promise<Card | undefined> {
    return this.cards.get(id);
  }

  async createCard(insertCard: InsertCard): Promise<Card> {
    const id = this.cardIdCounter++;
    // Ensure required fields are present
    const cardWithDefaults = {
      ...insertCard,
      balance: insertCard.balance || "1250.75", // Always ensure a valid balance
      id
    };
    
    const card: Card = cardWithDefaults;
    this.cards.set(id, card);
    return card;
  }

  async deleteCard(id: number): Promise<boolean> {
    return this.cards.delete(id);
  }
}

// Initialize storage
export const storage = new MemStorage();

// Create a demo user for testing if needed
(async () => {
  const demoUser = await storage.getUserByUsername("demo");
  if (!demoUser) {
    await storage.createUser({
      username: "demo",
      password: "demo1234",
      useFaceId: false
    });
  }
})();
