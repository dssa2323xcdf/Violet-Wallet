import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CardForm from '@/components/CardForm';
import Navigation from '@/components/Navigation';

export default function AddCard() {
  const [_, setLocation] = useLocation();
  
  // Get userId from localStorage
  const userId = parseInt(localStorage.getItem('userId') || '0');
  
  // Redirect to login if no userId
  useEffect(() => {
    if (!userId) {
      // For demo purposes, we'll use the demo user
      localStorage.setItem('userId', '1');
    }
  }, [userId]);
  
  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      <header className="p-6 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-4"
          onClick={() => setLocation('/')}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-300 bg-clip-text text-transparent">
            Add New Card
          </h1>
          <p className="text-slate-400 text-sm">Enter your card details securely</p>
        </div>
      </header>
      
      <main className="p-6 max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-slate-900/60 backdrop-blur-sm rounded-lg p-6 border border-slate-800"
        >
          <CardForm userId={userId} />
        </motion.div>
        
        <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
          <p className="text-sm text-slate-300">
            <strong className="text-primary">Secure Storage:</strong> Your card details are encrypted and stored securely. We only display the last 4 digits of your card number.
          </p>
        </div>
      </main>
      
      <Navigation userId={userId} />
    </div>
  );
}
