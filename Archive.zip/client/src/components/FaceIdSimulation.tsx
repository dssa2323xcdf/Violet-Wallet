import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Fingerprint, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FaceIdSimulationProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export function FaceIdSimulation({ onSuccess, onCancel }: FaceIdSimulationProps) {
  const [status, setStatus] = useState<'scanning' | 'success' | 'failed'>('scanning');
  
  // Simulate Face ID scanning
  useEffect(() => {
    if (status === 'scanning') {
      const timer = setTimeout(() => {
        // Always succeed in this simulation
        setStatus('success');
        
        // Call onSuccess after showing the success animation
        setTimeout(() => {
          onSuccess();
        }, 1000);
      }, 2500);
      
      return () => clearTimeout(timer);
    }
  }, [status, onSuccess]);
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center"
    >
      <div className="absolute top-4 right-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onCancel}
          className="text-white"
        >
          <X className="h-6 w-6" />
        </Button>
      </div>
      
      <div className="flex flex-col items-center">
        <div className="relative w-32 h-32 mb-6">
          {/* Face ID animation */}
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-primary"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ 
              scale: [0.8, 1.1, 0.9],
              opacity: [0, 0.8, 0],
            }}
            transition={{ 
              repeat: status === 'scanning' ? Infinity : 0,
              duration: 2
            }}
          />
          
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            animate={{
              opacity: status === 'success' ? [1, 0, 1] : 1,
            }}
            transition={{ duration: 0.5 }}
          >
            <Fingerprint
              className={`h-20 w-20 ${
                status === 'success' ? 'text-green-500' : 
                status === 'failed' ? 'text-red-500' : 'text-primary'
              }`}
            />
          </motion.div>
          
          {status === 'success' && (
            <motion.div
              className="absolute inset-0 bg-green-500/20 rounded-full"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1.2, opacity: 1 }}
              transition={{ duration: 0.5 }}
            />
          )}
        </div>
        
        <motion.p
          className="text-white text-xl font-medium"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          {status === 'scanning' && 'Scanning...'}
          {status === 'success' && 'Face ID Enabled!'}
          {status === 'failed' && 'Scan Failed'}
        </motion.p>
        
        <motion.p
          className="text-slate-400 text-sm mt-2 max-w-xs text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          {status === 'scanning' && 'Look at the camera to authenticate'}
          {status === 'success' && 'You can now use Face ID to sign in'}
          {status === 'failed' && 'Please try again or use another method'}
        </motion.p>
      </div>
    </motion.div>
  );
}

export default FaceIdSimulation;
