import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Fingerprint, Shield, LogOut } from 'lucide-react';
import FaceIdSimulation from './FaceIdSimulation';

interface SettingsPanelProps {
  userId: number;
  onLogout: () => void;
}

export function SettingsPanel({ userId, onLogout }: SettingsPanelProps) {
  const [showFaceIdAnimation, setShowFaceIdAnimation] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch user settings
  const { 
    data: user, 
    isLoading,
    isError
  } = useQuery({
    queryKey: [`/api/users/${userId}`]
  });
  
  // Toggle Face ID mutation
  const toggleFaceIdMutation = useMutation({
    mutationFn: async (useFaceId: boolean) => {
      const response = await apiRequest('PATCH', `/api/users/${userId}/faceid`, { useFaceId });
      return response.json();
    },
    onSuccess: () => {
      // Invalidate the user settings query
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      toast({
        title: 'Settings Updated',
        description: user?.useFaceId ? 'Face ID has been disabled.' : 'Face ID has been enabled.',
      });
    },
    onError: (error) => {
      console.error('Error updating settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to update settings. Please try again.',
        variant: 'destructive',
      });
    },
  });
  
  // Handle Face ID toggle
  const handleFaceIdToggle = async (checked: boolean) => {
    if (checked) {
      // Show Face ID animation before enabling
      setShowFaceIdAnimation(true);
    } else {
      // Just disable it
      await toggleFaceIdMutation.mutate(false);
    }
  };
  
  // Handle Face ID animation completion
  const handleFaceIdSuccess = async () => {
    setShowFaceIdAnimation(false);
    await toggleFaceIdMutation.mutate(true);
  };
  
  const handleFaceIdCancel = () => {
    setShowFaceIdAnimation(false);
  };
  
  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4 p-4">
        <div className="h-8 bg-slate-700 rounded w-1/2"></div>
        <div className="h-24 bg-slate-700 rounded"></div>
        <div className="h-24 bg-slate-700 rounded"></div>
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="p-4 text-center">
        <p className="text-red-500">Failed to load settings. Please try again.</p>
        <Button 
          variant="outline" 
          className="mt-4"
          onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] })}
        >
          Retry
        </Button>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {showFaceIdAnimation && (
        <FaceIdSimulation
          onSuccess={handleFaceIdSuccess}
          onCancel={handleFaceIdCancel}
        />
      )}
      
      <Card className="border-slate-800 bg-slate-900/60">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Fingerprint className="mr-2 h-5 w-5 text-primary" />
            Face ID Authentication
          </CardTitle>
          <CardDescription>
            Enable Face ID to quickly authenticate when accessing your cards.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <Label htmlFor="face-id-toggle" className="text-sm">
              Use Face ID
            </Label>
            <Switch
              id="face-id-toggle"
              checked={user?.useFaceId || false}
              onCheckedChange={handleFaceIdToggle}
              disabled={toggleFaceIdMutation.isPending}
            />
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-slate-800 bg-slate-900/60">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="mr-2 h-5 w-5 text-primary" />
            Security Settings
          </CardTitle>
          <CardDescription>
            Manage your account security and preferences.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="text-sm font-medium mb-1">Username</div>
            <div className="text-sm text-muted-foreground">{user?.username}</div>
          </div>
          <Separator className="my-4 bg-slate-800" />
          <div>
            <div className="text-sm font-medium mb-1">Card Encryption</div>
            <div className="text-sm text-muted-foreground">All card data is encrypted and stored securely.</div>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            variant="destructive" 
            className="w-full"
            onClick={onLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Log Out
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

export default SettingsPanel;
