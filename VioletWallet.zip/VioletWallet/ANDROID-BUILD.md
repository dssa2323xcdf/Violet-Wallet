# Building Card Wallet APK

## Prerequisites
- Android Studio
- JDK 11+
- Android SDK

## Build Steps

1. Open the android folder in Android Studio:
   ```
   android/
   ```

2. Let Android Studio sync the project

3. Build the APK:
   Build > Build Bundle(s) / APK(s) > Build APK(s)

4. The APK will be available at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

## Features
- NFC payment simulation
- 3D card management
- Dark theme with purple LED accents
