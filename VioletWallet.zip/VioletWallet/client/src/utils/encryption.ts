// This is a simplified encryption utility for demonstration purposes
// In a production app, you would use a proper encryption library

/**
 * Encrypts sensitive card data
 * @param data The sensitive data to encrypt
 * @returns The encrypted data
 */
export function encryptData(data: string): string {
  // In a real application, we would use a proper encryption algorithm
  // This is a very simplified version for demonstration
  return btoa(reversString(data));
}

/**
 * Decrypts encrypted card data
 * @param encryptedData The encrypted data
 * @returns The decrypted data
 */
export function decryptData(encryptedData: string): string {
  // In a real application, we would use a proper decryption algorithm
  // This is a very simplified version for demonstration
  return reversString(atob(encryptedData));
}

/**
 * Helper function to reverse a string (part of our simple encryption)
 */
function reversString(str: string): string {
  return str.split('').reverse().join('');
}

/**
 * Masks a card number leaving only the last 4 digits visible
 * @param cardNumber The full card number
 * @returns The masked card number
 */
export function maskCardNumber(cardNumber: string): string {
  return cardNumber.slice(-4).padStart(cardNumber.length, '*');
}

/**
 * Gets the last 4 digits of a card number
 * @param cardNumber The full card number
 * @returns The last 4 digits
 */
export function getLastFourDigits(cardNumber: string): string {
  return cardNumber.slice(-4);
}

/**
 * Determines the card type based on the card number
 * @param cardNumber The card number
 * @returns The card type (Visa, Mastercard, etc.)
 */
export function getCardType(cardNumber: string): string {
  // Very simplified card type detection
  const firstDigit = cardNumber.charAt(0);
  const firstTwoDigits = parseInt(cardNumber.substring(0, 2));
  
  if (firstDigit === '4') {
    return 'Visa';
  } else if (firstTwoDigits >= 51 && firstTwoDigits <= 55) {
    return 'Mastercard';
  } else if (firstTwoDigits === 34 || firstTwoDigits === 37) {
    return 'American Express';
  } else if (firstTwoDigits === 60) {
    return 'Discover';
  }
  
  return 'Unknown';
}

/**
 * Formats a card number for display with spaces
 * @param cardNumber The card number
 * @returns The formatted card number
 */
export function formatCardNumber(cardNumber: string): string {
  return cardNumber.replace(/(\d{4})/g, '$1 ').trim();
}
