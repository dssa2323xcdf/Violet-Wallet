import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SettingsPanel from '@/components/SettingsPanel';
import Navigation from '@/components/Navigation';

export default function Settings() {
  const [location, setLocation] = useLocation();
  
  // Get userId from localStorage
  const userId = parseInt(localStorage.getItem('userId') || '0');
  
  // Redirect to login if no userId
  useEffect(() => {
    if (!userId) {
      // For demo purposes, we'll use the demo user
      localStorage.setItem('userId', '1');
    }
  }, [userId]);
  
  const handleLogout = () => {
    // Clear localStorage
    localStorage.removeItem('userId');
    // Redirect to home (which will handle authentication)
    setLocation('/');
  };
  
  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      <header className="p-6 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-4"
          onClick={() => setLocation('/')}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-300 bg-clip-text text-transparent">
            Settings
          </h1>
          <p className="text-slate-400 text-sm">Manage your account and security</p>
        </div>
      </header>
      
      <main className="p-6 max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <SettingsPanel userId={userId} onLogout={handleLogout} />
        </motion.div>
      </main>
      
      <Navigation userId={userId} />
    </div>
  );
}
