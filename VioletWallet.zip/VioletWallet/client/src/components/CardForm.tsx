import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CardFormData, cardFormSchema } from '@shared/schema';
import { encryptData, getCardType, getLastFourDigits } from '@/utils/encryption';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { CreditCard, RotateCw } from 'lucide-react';

interface CardFormProps {
  userId: number;
}

export function CardForm({ userId }: CardFormProps) {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [cardColor, setCardColor] = useState('purple');
  
  // Current year and month for validation
  const currentYear = new Date().getFullYear() % 100;
  const currentMonth = new Date().getMonth() + 1;
  
  // Years for expiry dropdown
  const years = Array.from({ length: 10 }, (_, i) => currentYear + i);
  
  // Months for expiry dropdown
  const months = Array.from({ length: 12 }, (_, i) => {
    const month = i + 1;
    return month < 10 ? `0${month}` : `${month}`;
  });
  
  // Define form with validation
  const form = useForm<CardFormData>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      userId,
      cardholderName: '',
      cardNumber: '',
      cvv: '',
      expiryMonth: currentMonth < 10 ? `0${currentMonth}` : `${currentMonth}`,
      expiryYear: `${currentYear}`,
      cardType: '',
      lastFourDigits: '',
      encryptedCardNumber: '',
      encryptedCvv: '',
      color: cardColor,
    },
  });
  
  // Handle form submission
  const addCardMutation = useMutation({
    mutationFn: async (formData: CardFormData) => {
      // Process the card data before sending to the API
      const cardType = getCardType(formData.cardNumber);
      const lastFourDigits = getLastFourDigits(formData.cardNumber);
      const encryptedCardNumber = encryptData(formData.cardNumber);
      const encryptedCvv = encryptData(formData.cvv);
      
      // Create the card object to send to the API
      const cardData = {
        userId,
        cardholderName: formData.cardholderName,
        lastFourDigits,
        encryptedCardNumber,
        encryptedCvv,
        expiryMonth: formData.expiryMonth,
        expiryYear: formData.expiryYear,
        cardType,
        color: cardColor,
      };
      
      // Send the card data to the API
      const response = await apiRequest('POST', `/api/users/${userId}/cards`, cardData);
      return response.json();
    },
    onSuccess: () => {
      // Show success message
      toast({
        title: 'Card Added',
        description: 'Your card has been added successfully.',
      });
      
      // Invalidate queries to refresh card list
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/cards`] });
      
      // Navigate back to the home page
      setLocation('/');
    },
    onError: (error) => {
      console.error('Error adding card:', error);
      toast({
        title: 'Error',
        description: 'Failed to add your card. Please try again.',
        variant: 'destructive',
      });
    },
  });
  
  // Handle form submission
  function onSubmit(data: CardFormData) {
    addCardMutation.mutate(data);
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-4">
          <FormField
            control={form.control}
            name="cardholderName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Cardholder Name</FormLabel>
                <FormControl>
                  <Input placeholder="John Doe" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="cardNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Card Number</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="1234 5678 9012 3456" 
                    maxLength={19}
                    {...field}
                    onChange={(e) => {
                      // Allow only numbers
                      const value = e.target.value.replace(/\D/g, '');
                      
                      // Check if this is a potentially valid card based on prefix
                      const cardType = getCardType(value);
                      if (cardType === "Unknown" && value.length > 4) {
                        // If card type is unknown after first 4 digits, show a warning
                        form.setError("cardNumber", {
                          type: "manual",
                          message: "Card number not recognized as a valid card type"
                        });
                      } else {
                        form.clearErrors("cardNumber");
                      }
                      
                      field.onChange(value);
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="expiryMonth"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Expiry Month</FormLabel>
                    <FormControl>
                      <Select 
                        value={field.value} 
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="MM" />
                        </SelectTrigger>
                        <SelectContent>
                          {months.map((month) => (
                            <SelectItem key={month} value={month}>
                              {month}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="expiryYear"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Expiry Year</FormLabel>
                    <FormControl>
                      <Select 
                        value={field.value} 
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="YY" />
                        </SelectTrigger>
                        <SelectContent>
                          {years.map((year) => (
                            <SelectItem key={year} value={`${year}`}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
          
          <FormField
            control={form.control}
            name="cvv"
            render={({ field }) => (
              <FormItem>
                <FormLabel>CVV</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="123" 
                    maxLength={4}
                    type="password"
                    {...field}
                    onChange={(e) => {
                      // Allow only numbers
                      const value = e.target.value.replace(/\D/g, '');
                      field.onChange(value);
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div>
            <FormLabel>Card Color</FormLabel>
            <div className="flex gap-3 mt-2">
              {['purple', 'blue', 'black', 'gold'].map((color) => (
                <div
                  key={color}
                  className={`w-10 h-10 rounded-full cursor-pointer transition-all ${
                    cardColor === color ? 'ring-2 ring-white ring-offset-2 ring-offset-slate-900' : ''
                  }`}
                  style={{
                    background: 
                      color === 'purple' ? 'linear-gradient(135deg, #8A2BE2 0%, #4B0082 100%)' :
                      color === 'blue' ? 'linear-gradient(135deg, #1E90FF 0%, #0000CD 100%)' :
                      color === 'black' ? 'linear-gradient(135deg, #2C3E50 0%, #000000 100%)' :
                      'linear-gradient(135deg, #FFD700 0%, #B8860B 100%)'
                  }}
                  onClick={() => {
                    setCardColor(color);
                    form.setValue('color', color);
                  }}
                />
              ))}
            </div>
          </div>
        </div>
        
        <Button 
          type="submit" 
          className="w-full" 
          disabled={addCardMutation.isPending}
        >
          {addCardMutation.isPending ? (
            <>
              <RotateCw className="mr-2 h-4 w-4 animate-spin" />
              Adding Card...
            </>
          ) : (
            <>
              <CreditCard className="mr-2 h-4 w-4" />
              Add Card
            </>
          )}
        </Button>
      </form>
    </Form>
  );
}

export default CardForm;
