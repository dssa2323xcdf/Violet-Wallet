import { useState, useRef } from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { Card } from '@shared/schema';
import { Wallet } from 'lucide-react';

interface Card3DProps {
  card: Card;
  isSelected: boolean;
  onClick: () => void;
  onQuickPay?: () => void;
  style?: React.CSSProperties;
}

export function Card3D({ card, isSelected, onClick, onQuickPay, style }: Card3DProps) {
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Motion values for 3D effect
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  // Transform mouse movement to rotation
  const rotateY = useTransform(x, [-300, 300], [10, -10]);
  const rotateX = useTransform(y, [-300, 300], [-10, 10]);
  
  // Handling mouse move for 3D effect
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current || !isHovered) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    x.set(e.clientX - centerX);
    y.set(e.clientY - centerY);
  };
  
  // Reset position when not hovering
  const handleMouseLeave = () => {
    setIsHovered(false);
    x.set(0);
    y.set(0);
  };
  
  // Quick pay handler with stopPropagation
  const handleQuickPay = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card from being selected
    if (onQuickPay) {
      onQuickPay();
    }
  };
  
  // Get a gradient based on the card color
  const getCardGradient = () => {
    switch(card.color) {
      case 'purple':
        return 'linear-gradient(135deg, #8A2BE2 0%, #4B0082 100%)';
      case 'blue':
        return 'linear-gradient(135deg, #1E90FF 0%, #0000CD 100%)';
      case 'black':
        return 'linear-gradient(135deg, #2C3E50 0%, #000000 100%)';
      case 'gold':
        return 'linear-gradient(135deg, #FFD700 0%, #B8860B 100%)';
      default:
        return 'linear-gradient(135deg, #8A2BE2 0%, #4B0082 100%)';
    }
  };
  
  // Format balance with currency symbol
  const formatBalance = (balance: string = '0.00') => {
    const numBalance = parseFloat(balance);
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(numBalance);
  };
  
  return (
    <div className="flex flex-col items-center">
      <motion.div
        ref={containerRef}
        className={`relative cursor-pointer ${isSelected ? 'z-10' : 'z-0'}`}
        style={{
          perspective: '1000px',
          ...style
        }}
        onClick={onClick}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={handleMouseLeave}
        whileHover={{ scale: 1.05 }}
        animate={{ 
          scale: isSelected ? 1.1 : 1,
          y: isSelected ? -20 : 0
        }}
        transition={{ duration: 0.3 }}
      >
        <motion.div
          className="w-72 h-44 rounded-xl p-5 relative overflow-hidden shadow-lg"
          style={{
            backgroundColor: 'transparent',
            background: getCardGradient(),
            boxShadow: isSelected 
              ? '0 20px 30px rgba(107, 47, 217, 0.3), 0 0 15px rgba(157, 92, 255, 0.5)'
              : '0 10px 20px rgba(0, 0, 0, 0.2)',
            transformStyle: 'preserve-3d',
            rotateY,
            rotateX,
          }}
        >
          {/* Card shine effect */}
          <div 
            className="absolute inset-0 opacity-30 z-0" 
            style={{ 
              background: 'linear-gradient(135deg, rgba(255,255,255,0.3) 0%, rgba(255,255,255,0) 50%, rgba(255,255,255,0) 100%)',
              transformStyle: 'preserve-3d',
            }}
          />
          
          {/* Card chip */}
          <div 
            className="w-12 h-9 rounded-md mb-4"
            style={{ 
              background: 'linear-gradient(135deg, #FFD700 0%, #B8860B 100%)',
              boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
              transformStyle: 'preserve-3d',
              transform: 'translateZ(10px)'
            }}
          >
            <div className="grid grid-cols-2 gap-1 p-1 h-full">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-black/20 rounded-sm"></div>
              ))}
            </div>
          </div>
          
          {/* Card type logo */}
          <div 
            className="absolute top-5 right-5 text-white font-bold"
            style={{ 
              transformStyle: 'preserve-3d',
              transform: 'translateZ(10px)'
            }}
          >
            {card.cardType}
          </div>
          
          {/* Card number */}
          <div 
            className="mt-auto pt-2 font-mono text-lg text-white tracking-wider"
            style={{ 
              transformStyle: 'preserve-3d',
              transform: 'translateZ(10px)'
            }}
          >
            •••• •••• •••• {card.lastFourDigits}
          </div>
          
          {/* Card details */}
          <div 
            className="flex justify-between items-end mt-4"
            style={{ 
              transformStyle: 'preserve-3d',
              transform: 'translateZ(10px)'
            }}
          >
            <div>
              <div className="text-xs text-white/70 uppercase">Card Holder</div>
              <div className="text-sm text-white font-medium">{card.cardholderName}</div>
            </div>
            <div>
              <div className="text-xs text-white/70 uppercase">Expires</div>
              <div className="text-sm text-white">{card.expiryMonth}/{card.expiryYear}</div>
            </div>
          </div>
          
          {/* Purple glow effect */}
          <motion.div
            className="absolute inset-0 rounded-xl z-0"
            style={{
              background: 'radial-gradient(circle at center, rgba(107, 47, 217, 0.2) 0%, rgba(107, 47, 217, 0) 70%)',
              opacity: isHovered || isSelected ? 1 : 0,
              transformStyle: 'preserve-3d',
            }}
            animate={{ opacity: isHovered || isSelected ? 1 : 0 }}
            transition={{ duration: 0.5 }}
          />
        </motion.div>
      </motion.div>
      
      {isSelected && (
        <motion.div 
          className="bg-slate-950/90 backdrop-blur-sm rounded-xl mt-3 w-72 p-4 border border-slate-800 shadow-lg"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400">Available Balance</div>
              <div className="text-xl font-bold text-white">
                {formatBalance(card.balance)}
              </div>
            </div>
            
            <motion.button
              className="bg-primary rounded-full p-3 flex items-center justify-center"
              onClick={handleQuickPay}
              whileHover={{ scale: 1.1, boxShadow: "0 0 15px rgba(107, 47, 217, 0.5)" }}
              whileTap={{ scale: 0.95 }}
            >
              <Wallet className="h-5 w-5 text-white" />
              <span className="ml-2 text-sm font-medium text-white">Tap to Pay</span>
            </motion.button>
          </div>
        </motion.div>
      )}
    </div>
  );
}

export default Card3D;
