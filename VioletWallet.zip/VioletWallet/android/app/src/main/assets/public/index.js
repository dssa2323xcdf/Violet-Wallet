// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
var MemStorage = class {
  users;
  cards;
  userIdCounter;
  cardIdCounter;
  constructor() {
    this.users = /* @__PURE__ */ new Map();
    this.cards = /* @__PURE__ */ new Map();
    this.userIdCounter = 1;
    this.cardIdCounter = 1;
  }
  // User methods
  async getUser(id) {
    return this.users.get(id);
  }
  async getUserByUsername(username) {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  async createUser(insertUser) {
    const id = this.userIdCounter++;
    const user = {
      ...insertUser,
      id,
      useFaceId: insertUser.useFaceId ?? false
    };
    this.users.set(id, user);
    return user;
  }
  async updateUserFaceIdSetting(userId, useFaceId) {
    const user = await this.getUser(userId);
    if (!user) return void 0;
    const updatedUser = { ...user, useFaceId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  // Card methods
  async getCards(userId) {
    return Array.from(this.cards.values()).filter(
      (card) => card.userId === userId
    );
  }
  async getCard(id) {
    return this.cards.get(id);
  }
  async createCard(insertCard) {
    const id = this.cardIdCounter++;
    const cardWithDefaults = {
      ...insertCard,
      balance: insertCard.balance || "1250.75",
      // Always ensure a valid balance
      id
    };
    const card = cardWithDefaults;
    this.cards.set(id, card);
    return card;
  }
  async deleteCard(id) {
    return this.cards.delete(id);
  }
};
var storage = new MemStorage();
(async () => {
  const demoUser = await storage.getUserByUsername("demo");
  if (!demoUser) {
    await storage.createUser({
      username: "demo",
      password: "demo1234",
      useFaceId: false
    });
  }
})();

// shared/schema.ts
import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  useFaceId: boolean("use_face_id").default(false)
});
var insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  useFaceId: true
});
var cards = pgTable("cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  cardholderName: text("cardholder_name").notNull(),
  lastFourDigits: text("last_four_digits").notNull(),
  encryptedCardNumber: text("encrypted_card_number").notNull(),
  encryptedCvv: text("encrypted_cvv").notNull(),
  expiryMonth: text("expiry_month").notNull(),
  expiryYear: text("expiry_year").notNull(),
  cardType: text("card_type").notNull(),
  color: text("color").notNull(),
  balance: text("balance").notNull().default("1250.75")
});
var insertCardSchema = createInsertSchema(cards).omit({
  id: true
});
var cardFormSchema = insertCardSchema.extend({
  cardNumber: z.string().refine(
    (val) => /^\d{13,19}$/.test(val),
    { message: "Card number must be 13-19 digits" }
  ).refine(
    (val) => {
      let sum = 0;
      let shouldDouble = false;
      for (let i = val.length - 1; i >= 0; i--) {
        let digit = parseInt(val.charAt(i));
        if (shouldDouble) {
          digit = digit * 2;
          if (digit > 9) {
            digit = digit - 9;
          }
        }
        sum += digit;
        shouldDouble = !shouldDouble;
      }
      return sum % 10 === 0;
    },
    { message: "Invalid card number" }
  ),
  cvv: z.string().refine(
    (val) => /^\d{3,4}$/.test(val),
    { message: "CVV must be 3 or 4 digits" }
  ),
  expiryMonth: z.string().refine(
    (val) => /^(0[1-9]|1[0-2])$/.test(val),
    { message: "Expiry month must be between 01-12" }
  ),
  expiryYear: z.string().refine(
    (val) => {
      const currentYear = (/* @__PURE__ */ new Date()).getFullYear() % 100;
      const year = parseInt(val);
      return /^\d{2}$/.test(val) && year >= currentYear;
    },
    { message: "Expiry year must be valid and not in the past" }
  )
});

// server/routes.ts
async function registerRoutes(app2) {
  app2.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      return res.status(200).json({
        id: user.id,
        username: user.username,
        useFaceId: user.useFaceId
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  app2.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      return res.status(200).json({
        id: user.id,
        username: user.username,
        useFaceId: user.useFaceId
      });
    } catch (error) {
      console.error("Get user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  app2.patch("/api/users/:id/faceid", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const { useFaceId } = req.body;
      if (typeof useFaceId !== "boolean") {
        return res.status(400).json({ message: "useFaceId must be a boolean" });
      }
      const updatedUser = await storage.updateUserFaceIdSetting(userId, useFaceId);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      return res.status(200).json({
        id: updatedUser.id,
        username: updatedUser.username,
        useFaceId: updatedUser.useFaceId
      });
    } catch (error) {
      console.error("Update Face ID error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  app2.get("/api/users/:userId/cards", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const cards2 = await storage.getCards(userId);
      return res.status(200).json(cards2);
    } catch (error) {
      console.error("Get cards error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  app2.post("/api/users/:userId/cards", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const validationResult = insertCardSchema.safeParse({ ...req.body, userId });
      if (!validationResult.success) {
        return res.status(400).json({
          message: "Invalid card data",
          errors: validationResult.error.errors
        });
      }
      const newCard = await storage.createCard(validationResult.data);
      return res.status(201).json(newCard);
    } catch (error) {
      console.error("Add card error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  app2.delete("/api/cards/:id", async (req, res) => {
    try {
      const cardId = parseInt(req.params.id);
      if (isNaN(cardId)) {
        return res.status(400).json({ message: "Invalid card ID" });
      }
      const card = await storage.getCard(cardId);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      const success = await storage.deleteCard(cardId);
      if (!success) {
        return res.status(500).json({ message: "Failed to delete card" });
      }
      return res.status(200).json({ message: "Card deleted successfully" });
    } catch (error) {
      console.error("Delete card error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import themePlugin from "@replit/vite-plugin-shadcn-theme-json";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    themePlugin(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = 5e3;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
