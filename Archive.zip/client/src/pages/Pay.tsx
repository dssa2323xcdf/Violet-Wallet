import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { motion } from 'framer-motion';
import { ChevronLeft, CreditCard, DollarSign } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import Navigation from '@/components/Navigation';
import NFCPayment from '@/components/NFCPayment';
import CardStack from '@/components/CardStack';
import { Card as CardType } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

export default function Pay() {
  const [_, setLocation] = useLocation();
  const [selectedCardIndex, setSelectedCardIndex] = useState<number | null>(null);
  const [amount, setAmount] = useState<string>('');
  const [showNFC, setShowNFC] = useState(false);
  const { toast } = useToast();
  
  // Get userId from localStorage
  const userId = parseInt(localStorage.getItem('userId') || '0');
  
  // Redirect to login if no userId
  useEffect(() => {
    if (!userId) {
      // For demo purposes, we'll use the demo user
      localStorage.setItem('userId', '1');
    }
  }, [userId]);
  
  // Fetch cards
  const { 
    data: cards = [] as CardType[], 
    isLoading,
    refetch 
  } = useQuery<CardType[]>({
    queryKey: [`/api/users/${userId}/cards`],
    enabled: !!userId,
  });
  
  const handleCardClick = (index: number) => {
    setSelectedCardIndex(selectedCardIndex === index ? null : index);
  };
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Allow only numbers and decimal points
    const value = e.target.value.replace(/[^0-9.]/g, '');
    
    // Ensure only one decimal point
    const parts = value.split('.');
    if (parts.length > 2) {
      return;
    }
    
    // Limit to two decimal places
    if (parts.length === 2 && parts[1].length > 2) {
      return;
    }
    
    setAmount(value);
  };
  
  const handlePayClick = () => {
    if (selectedCardIndex === null) {
      toast({
        title: "No Card Selected",
        description: "Please select a card to pay with",
        variant: "destructive",
      });
      return;
    }
    
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    
    // Start NFC payment simulation
    setShowNFC(true);
  };
  
  const handlePaymentSuccess = () => {
    // Close NFC modal and show success message
    setShowNFC(false);
    toast({
      title: "Payment Successful",
      description: `$${parseFloat(amount).toFixed(2)} paid with your ${cards[selectedCardIndex!].cardType} card`,
    });
    // Reset the form
    setAmount('');
    setSelectedCardIndex(null);
  };
  
  const handlePaymentCancel = () => {
    setShowNFC(false);
  };
  
  return (
    <div className="min-h-screen bg-slate-950 text-white pb-20">
      {showNFC && selectedCardIndex !== null && (
        <NFCPayment
          card={cards[selectedCardIndex]}
          amount={parseFloat(amount)}
          onSuccess={handlePaymentSuccess}
          onCancel={handlePaymentCancel}
        />
      )}
      
      <header className="p-6 flex items-center">
        <Button
          variant="ghost"
          size="icon"
          className="mr-4"
          onClick={() => setLocation('/')}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-300 bg-clip-text text-transparent">
            Make Payment
          </h1>
          <p className="text-slate-400 text-sm">Select a card and enter amount</p>
        </div>
      </header>
      
      <main className="p-6 max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <section className="mb-8">
            <h2 className="text-xl font-medium mb-4">Select Payment Card</h2>
            
            <div className="relative h-48">
              {cards.length > 0 ? (
                <div className="grid grid-cols-1 gap-4">
                  {cards.map((card: CardType, index: number) => (
                    <div 
                      key={card.id}
                      className={`flex items-center p-3 rounded-lg cursor-pointer transition-all
                        ${selectedCardIndex === index 
                          ? 'bg-primary/20 border border-primary' 
                          : 'bg-slate-900/60 border border-slate-800 hover:border-slate-700'
                        }`}
                      onClick={() => handleCardClick(index)}
                    >
                      <div 
                        className="w-12 h-8 rounded-md mr-4"
                        style={{
                          background: 
                            card.color === 'purple' ? 'linear-gradient(135deg, #8A2BE2 0%, #4B0082 100%)' :
                            card.color === 'blue' ? 'linear-gradient(135deg, #1E90FF 0%, #0000CD 100%)' :
                            card.color === 'black' ? 'linear-gradient(135deg, #2C3E50 0%, #000000 100%)' :
                            'linear-gradient(135deg, #FFD700 0%, #B8860B 100%)'
                        }}
                      ></div>
                      <div>
                        <p className="font-medium">{card.cardType} •••• {card.lastFourDigits}</p>
                        <p className="text-sm text-slate-400">{card.cardholderName}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-slate-800 rounded-lg">
                  <CreditCard className="h-8 w-8 text-primary mb-2" />
                  <p className="text-slate-400">No cards available</p>
                  <Button 
                    variant="link" 
                    className="text-primary mt-2"
                    onClick={() => setLocation('/add-card')}
                  >
                    Add a card
                  </Button>
                </div>
              )}
            </div>
          </section>
          
          <section className="mb-8">
            <h2 className="text-xl font-medium mb-4">Payment Amount</h2>
            <Card className="bg-slate-900/60 border-slate-800">
              <div className="p-6">
                <div className="mb-4">
                  <Label htmlFor="amount" className="text-white mb-2 block">Amount</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <DollarSign className="h-5 w-5 text-slate-400" />
                    </div>
                    <Input
                      id="amount"
                      placeholder="0.00"
                      className="pl-10 bg-slate-800 border-slate-700 text-white text-lg"
                      value={amount}
                      onChange={handleAmountChange}
                    />
                  </div>
                </div>
                
                <Button 
                  className="w-full"
                  size="lg"
                  disabled={!amount || selectedCardIndex === null || isLoading}
                  onClick={handlePayClick}
                >
                  <DollarSign className="mr-2 h-4 w-4" />
                  Pay Now
                </Button>
              </div>
            </Card>
          </section>
          
          <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <p className="text-sm text-slate-300">
              <strong className="text-primary">NFC Payment:</strong> When you tap "Pay Now", please hold your device close to the payment terminal to complete the transaction.
            </p>
          </div>
        </motion.div>
      </main>
      
      <Navigation userId={userId} />
    </div>
  );
}