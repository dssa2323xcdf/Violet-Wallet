import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertCardSchema, 
  cardFormSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes - all prefixed with /api
  
  // User Routes
  
  // Login route
  app.post("/api/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // For simplicity, we're returning the user directly
      // In a real app, you'd want to use proper authentication with sessions/JWT
      return res.status(200).json({ 
        id: user.id, 
        username: user.username, 
        useFaceId: user.useFaceId 
      });
      
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get User Settings
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.status(200).json({ 
        id: user.id, 
        username: user.username, 
        useFaceId: user.useFaceId 
      });
      
    } catch (error) {
      console.error("Get user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Update Face ID Setting
  app.patch("/api/users/:id/faceid", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const { useFaceId } = req.body;
      if (typeof useFaceId !== 'boolean') {
        return res.status(400).json({ message: "useFaceId must be a boolean" });
      }
      
      const updatedUser = await storage.updateUserFaceIdSetting(userId, useFaceId);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.status(200).json({ 
        id: updatedUser.id, 
        username: updatedUser.username, 
        useFaceId: updatedUser.useFaceId 
      });
      
    } catch (error) {
      console.error("Update Face ID error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Card Routes
  
  // Get all cards for a user
  app.get("/api/users/:userId/cards", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const cards = await storage.getCards(userId);
      return res.status(200).json(cards);
      
    } catch (error) {
      console.error("Get cards error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Add a new card
  app.post("/api/users/:userId/cards", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Validate the card data
      const validationResult = insertCardSchema.safeParse({ ...req.body, userId });
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid card data", 
          errors: validationResult.error.errors 
        });
      }
      
      const newCard = await storage.createCard(validationResult.data);
      return res.status(201).json(newCard);
      
    } catch (error) {
      console.error("Add card error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Delete a card
  app.delete("/api/cards/:id", async (req: Request, res: Response) => {
    try {
      const cardId = parseInt(req.params.id);
      if (isNaN(cardId)) {
        return res.status(400).json({ message: "Invalid card ID" });
      }
      
      const card = await storage.getCard(cardId);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      
      const success = await storage.deleteCard(cardId);
      if (!success) {
        return res.status(500).json({ message: "Failed to delete card" });
      }
      
      return res.status(200).json({ message: "Card deleted successfully" });
      
    } catch (error) {
      console.error("Delete card error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
