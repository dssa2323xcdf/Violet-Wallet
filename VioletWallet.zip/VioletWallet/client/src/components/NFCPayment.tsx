import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Wifi, CheckCircle, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@shared/schema';

interface NFCPaymentProps {
  card: Card;
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export function NFCPayment({ card, amount, onSuccess, onCancel }: NFCPaymentProps) {
  const [status, setStatus] = useState<'initializing' | 'scanning' | 'processing' | 'success' | 'failed'>('initializing');
  const [progress, setProgress] = useState(0);
  
  // Simulate NFC payment process
  useEffect(() => {
    if (status === 'initializing') {
      // Simulate NFC initialization
      const timer = setTimeout(() => {
        setStatus('scanning');
      }, 1000);
      
      return () => clearTimeout(timer);
    }
    
    if (status === 'scanning') {
      // Simulate progress
      const interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + (Math.random() * 10);
          if (newProgress >= 100) {
            setStatus('processing');
            clearInterval(interval);
            return 100;
          }
          return newProgress;
        });
      }, 200);
      
      return () => clearInterval(interval);
    }
    
    if (status === 'processing') {
      // Simulate processing
      const timer = setTimeout(() => {
        // Always succeed in this simulation
        setStatus('success');
        
        // Call onSuccess after showing the success animation
        setTimeout(() => {
          onSuccess();
        }, 2000);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [status, onSuccess]);
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center"
    >
      <div className="absolute top-4 right-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onCancel}
          className="text-white"
        >
          <X className="h-6 w-6" />
        </Button>
      </div>
      
      <div className="flex flex-col items-center max-w-xs w-full mx-auto">
        <div className="relative w-40 h-40 mb-6 flex items-center justify-center">
          {status === 'initializing' && (
            <div className="text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                <motion.div
                  animate={{ scale: [1, 1.1, 1], opacity: [0.8, 1, 0.8] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                >
                  <Wifi className="h-24 w-24 text-primary" />
                </motion.div>
              </motion.div>
              <p className="text-white mt-2">Initializing NFC...</p>
            </div>
          )}
          
          {status === 'scanning' && (
            <div className="text-center">
              <div className="relative">
                <svg className="w-32 h-32" viewBox="0 0 100 100">
                  <circle 
                    cx="50" 
                    cy="50" 
                    r="40" 
                    fill="none" 
                    stroke="#333" 
                    strokeWidth="8"
                  />
                  <motion.circle 
                    cx="50" 
                    cy="50" 
                    r="40" 
                    fill="none" 
                    stroke="#6B2FD9" 
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray="250 250"
                    strokeDashoffset={250 - ((progress / 100) * 250)}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    <Wifi className="h-16 w-16 text-primary" />
                  </motion.div>
                </div>
              </div>
              <p className="text-white mt-2">Hold phone near terminal...</p>
            </div>
          )}
          
          {status === 'processing' && (
            <div className="text-center">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="w-32 h-32 rounded-full border-4 border-primary flex items-center justify-center"
              >
                <motion.div
                  animate={{ 
                    rotate: 360,
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    rotate: { repeat: Infinity, duration: 2, ease: "linear" },
                    scale: { repeat: Infinity, duration: 1 }
                  }}
                >
                  <Wifi className="h-16 w-16 text-primary" />
                </motion.div>
              </motion.div>
              <p className="text-white mt-2">Processing payment...</p>
            </div>
          )}
          
          {status === 'success' && (
            <div className="text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 10 }}
              >
                <CheckCircle className="h-24 w-24 text-green-500" />
              </motion.div>
              <p className="text-white text-lg font-medium mt-2">Payment Successful!</p>
              <p className="text-slate-400 text-sm mt-1">Amount: ${amount.toFixed(2)}</p>
            </div>
          )}
          
          {status === 'failed' && (
            <div className="text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 10 }}
              >
                <AlertTriangle className="h-24 w-24 text-red-500" />
              </motion.div>
              <p className="text-white text-lg font-medium mt-2">Payment Failed</p>
              <p className="text-slate-400 text-sm mt-1">Please try again</p>
            </div>
          )}
        </div>
        
        <div className="bg-slate-900/80 p-4 rounded-lg w-full mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-slate-400">Card</span>
            <span className="text-white font-medium">{card.cardType} •••• {card.lastFourDigits}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Amount</span>
            <span className="text-white font-medium">${amount.toFixed(2)}</span>
          </div>
        </div>
        
        {status !== 'success' && status !== 'failed' && (
          <p className="text-slate-400 text-sm text-center max-w-xs">
            Hold your phone near the payment terminal to complete the transaction.
          </p>
        )}
      </div>
    </motion.div>
  );
}

export default NFCPayment;